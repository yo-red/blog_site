<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>データベース</title>
</head>
<body>

<?php

$dsn = 'mysql:dbname=comedian;host=localhost';
$user = 'yosuke@pp';
$password = 'D!Jzh3N/niL$@Bc';

try{
    $dbh = new PDO($dsn, $user, $password);

    $sql = 'select * from geinin';
    foreach ($dbh->query($sql) as $row) {
        print($row['id'].',');
        print($row['name']);
        print('<br />');
    }
}catch (PDOException $e){
    print('Error:'.$e->getMessage());
    die();
}

$dbh = null;

?>
  <a href="index.php">index.php</a>
  <br>
<?php
  echo 'Hello';
?>
</body>
</html>
  
