"use strict";

{
  // 時計
  function clock(){
    // 曜日文字列
    const weeks = new Array("日","月","火","水","木","金","土");
    // 現在日時
    const now = new Date();
    // 年
    const y = now.getFullYear();
    // 月
    const mo = now.getMonth() + 1;
    // 日
    const d = now.getDate();
    // 曜日
    const w = weeks[now.getDay()];
    // 時
    let h = now.getHours();
    // 分
    let mi = now.getMinutes();
    // 秒
    let s = now.getSeconds();
    // 2桁表示の処理
    if(h < 10) {
      h = "0" + h;
    };
    if(mi < 10) {
      mi = "0" + mi;
    };
    if(s < 10) {
      s = "0" + s;
    };

    document.getElementById("clock_data").innerHTML = y + "年" + mo + "月" + d + "日" + "(" + w + ")" + h + ":" + s;
  }

  setInterval(clock, 1000);
}